#! /bin/sh
python ./tests/alltests.py