#! /bin/sh
python ./UnitTests/alltests.py