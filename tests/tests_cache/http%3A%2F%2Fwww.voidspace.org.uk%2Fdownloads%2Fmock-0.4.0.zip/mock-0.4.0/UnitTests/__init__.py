# Copyright (C) 2007-2008 Michael Foord
# E-mail: fuzzyman AT voidspace DOT org DOT uk
# http://www.voidspace.org.uk/python/mock.html

from mocktest import MockTest
from sentineltest import SentinelTest
from patchtest import PatchTest
